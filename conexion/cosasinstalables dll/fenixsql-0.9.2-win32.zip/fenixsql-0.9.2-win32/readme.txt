compiled with
  freepascal 2.6.0 32bit
  lazarus 1.0.6
  fblib 0.86

tested on
   windows xp/vista/7
   ubuntu 12.4
 
in ubuntu 12.04 install fblient library
  sudo apt-get install libfbclient2
create  symbolic link    
  32-bit 
    sudo ln -s /usr/lib/i386-linux-gnu/libfbclient.so.2 /usr/lib/i386-linux-gnu/libfbclient.so
  64-bit
    sudo ln -s /usr/lib/x86_64-linux-gnu/libfbclient.so.2 /usr/lib/x86_64-linux-gnu/libfbclient.so



 

